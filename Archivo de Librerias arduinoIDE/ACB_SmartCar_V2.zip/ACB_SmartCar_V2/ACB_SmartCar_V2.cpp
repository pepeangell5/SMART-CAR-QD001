#include "ACB_SmartCar_V2.h"
#include "Arduino.h"

void ACB_SmartCar_V2::Init() 
{
    Serial_2 = new SoftwareSerial(RX_PIN, TX_PIN);
    Serial_2->begin(9600);
    pinMode(TX_PIN, OUTPUT);
    digitalWrite(TX_PIN, HIGH);

    motorControl(1, 0);   
    motorControl(2, 0);  
    motorControl(3, 0);  
    motorControl(4, 0); 

}

void ACB_SmartCar_V2::motorControl(uint8_t motor, int speed)
{
    if (Serial_2 == nullptr) return;  // 安全检查

    uint8_t dir = 0;
    uint8_t speed_value = 0;
    if(motor == 1 || motor == 2 ){
       dir = speed > 0 ? 1 : 2;
       speed_value = map(abs(speed), 0, 255, 0, 100);
    }

    if(motor == 3 || motor == 4 ){
       dir = speed > 0 ? 2 : 1;
       speed_value = map(abs(speed), 0, 255, 0, 100);
    }

    if(speed_value == 40)speed_value = 0;

    // 使用软件串口发送数据
    Serial_2->write(motor);       // 电机索引
    Serial_2->write(dir);         // 方向 (1:正转, 2:反转)
    Serial_2->write(speed_value); // 速度值 (0-255)
    Serial_2->write('\r');        // 回车
    Serial_2->write('\n');        // 换行
}

void ACB_SmartCar_V2::Move(int Dir, int Speed = 0) 
{ 
    if(Dir == 163){                       //前进 forward
      motorControl(1, Speed);   
      motorControl(2, Speed);  
      motorControl(3, Speed);  
      motorControl(4, Speed);   
    }

    if(Dir == 92){                        //后退 back
      motorControl(1, -Speed);   
      motorControl(2, -Speed);  
      motorControl(3, -Speed);  
      motorControl(4, -Speed);   
    }

    if(Dir ==  149){                        //右移动 Right
      motorControl(1, Speed);   
      motorControl(2, -Speed);  
      motorControl(3, -Speed);  
      motorControl(4, Speed);   
    }

    if(Dir == 106){                        //左移动 left
      motorControl(1, -Speed);   
      motorControl(2, Speed);  
      motorControl(3, Speed);  
      motorControl(4, -Speed);   
    }

    if(Dir ==  172){                        //顺时针 Counterclockwise rotation
      motorControl(1, Speed);   
      motorControl(2, Speed);  
      motorControl(3, -Speed);  
      motorControl(4, -Speed);   
    }

    if(Dir ==  83){                        //逆时针 Rotate clockwise
      motorControl(1, -Speed);   
      motorControl(2, -Speed);  
      motorControl(3, Speed);  
      motorControl(4, Speed); 
    }

    if(Dir == 34){                        //左上移 Top_Left
      motorControl(1, 0);   
      motorControl(2, Speed);  
      motorControl(3, Speed);  
      motorControl(4, 0);  
    }

    if(Dir ==  129){                        //右上移 Top_Right
      motorControl(1, Speed);   
      motorControl(2, 0);  
      motorControl(3, 0);  
      motorControl(4, Speed);  
    }

    if(Dir == 20){                        // 右下移  Bottom_Right
      motorControl(1, 0);   
      motorControl(2, -Speed);  
      motorControl(3, -Speed);  
      motorControl(4, 0);  
    }

    if(Dir ==  72){                        // 左下移 Bottom_Left
      motorControl(1, -Speed);   
      motorControl(2, 0);  
      motorControl(3, 0);  
      motorControl(4, -Speed);   
    }

    if(Dir == 0){
      motorControl(1, 0);   
      motorControl(2, 0);  
      motorControl(3, 0);  
      motorControl(4, 0);   
    }
}